"""Name handling."""


def normalize_name(name):
    """Trim the name and make it lower case."""
    name.strip()
    name.lower()
    return name


def initials(name):
    return "".join(part[0].upper() for part in name.split())
