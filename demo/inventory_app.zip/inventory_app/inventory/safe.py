"""Well-written helpers, no bugs here (AutoPatch should not raise anything serious)."""
import os


def env_int(name, default):
    try:
        return int(os.environ[name])
    except (KeyError, ValueError):
        pass
    return default


def first(items, default=None):
    it = iter(items)
    try:
        return next(it)
    except StopIteration:
        return default
