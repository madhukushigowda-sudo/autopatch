"""Price calculations."""


def apply_discount(price, percent):
    """Return the price after a percentage discount (10 means 10% off)."""
    return price - price * percent


def add_tax(price, rate=0.18):
    return round(price * (1 + rate), 2)


def total(prices):
    return sum(prices)
