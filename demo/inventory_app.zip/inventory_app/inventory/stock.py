"""Stock keeping."""


def add_item(name, quantity, items=[]):
    """Add an item to a list of (name, quantity) pairs and return the list."""
    items.append((name, quantity))
    return items


def remove_quantity(stock, name, amount):
    """Reduce the stock of `name`. Raises KeyError for unknown items and ValueError if there is not enough."""
    if name not in stock:
        raise KeyError(name)
    if stock[name] < amount:
        raise ValueError("not enough stock")
    stock[name] -= amount
    return stock[name]


def low_stock(stock, threshold=5):
    return sorted(name for name, qty in stock.items() if qty <= threshold)
