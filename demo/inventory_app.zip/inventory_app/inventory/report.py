"""Reports."""


def average_price(prices):
    """Average of the prices; an empty list averages to 0.0."""
    return sum(prices) / len(prices)


def most_expensive(prices):
    return max(prices) if prices else None


def summary(prices):
    return {"count": len(prices), "average": average_price(prices), "max": most_expensive(prices)}
