"""Sorting helpers."""


def cheapest_first(items):
    """Return items sorted by price (items are (name, price) pairs)."""
    items = items.sort(key=lambda pair: pair[1])
    return items


def names(items):
    return [name for name, _ in items]
