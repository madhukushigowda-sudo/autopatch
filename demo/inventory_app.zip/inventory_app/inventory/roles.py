"""Access rules."""


def can_edit(role):
    return role is "admin" or role is "manager"


def describe(role):
    return f"role={role}"
