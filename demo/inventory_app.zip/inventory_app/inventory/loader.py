"""Loading stock from text lines like 'apple,10'."""


def parse_line(line):
    name, qty = line.split(",")
    return name.strip(), int(qty)


def load(lines):
    stock = {}
    for line in lines:
        try:
            name, qty = parse_line(line)
            stock[name] = qty
        except Exception:
            pass
    return stock
