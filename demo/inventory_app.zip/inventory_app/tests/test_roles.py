from inventory.roles import can_edit, describe


def test_admin_can_edit():
    assert can_edit("admin") is True


def test_built_string_role():
    assert can_edit("".join(["ad", "min"])) is True


def test_viewer_cannot():
    assert can_edit("viewer") is False


def test_describe():
    assert describe("x") == "role=x"
