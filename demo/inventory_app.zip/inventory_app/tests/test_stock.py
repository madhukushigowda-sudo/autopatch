import pytest

from inventory.stock import add_item, low_stock, remove_quantity


def test_add_item_does_not_leak_between_calls():
    first = add_item("apple", 3)
    second = add_item("pear", 1)
    assert second == [("pear", 1)]
    assert first == [("apple", 3)]


def test_remove_quantity():
    assert remove_quantity({"a": 5}, "a", 2) == 3


def test_remove_too_much():
    with pytest.raises(ValueError):
        remove_quantity({"a": 1}, "a", 2)


def test_low_stock():
    assert low_stock({"a": 1, "b": 50, "c": 5}) == ["a", "c"]
