from inventory.safe import env_int, first


def test_env_default(monkeypatch):
    monkeypatch.delenv("NOPE_X", raising=False)
    assert env_int("NOPE_X", 7) == 7


def test_first():
    assert first([]) is None and first([4, 5]) == 4
