from inventory.report import average_price, most_expensive, summary


def test_average():
    assert average_price([2, 4]) == 3


def test_average_of_nothing_is_zero():
    assert average_price([]) == 0.0


def test_most_expensive():
    assert most_expensive([1, 9, 3]) == 9


def test_summary_empty():
    assert summary([]) == {"count": 0, "average": 0.0, "max": None}
