from inventory.pricing import add_tax, apply_discount, total


def test_discount_ten_percent():
    assert apply_discount(200, 10) == 180


def test_discount_zero():
    assert apply_discount(50, 0) == 50


def test_tax():
    assert add_tax(100) == 118.0


def test_total():
    assert total([1, 2, 3]) == 6
