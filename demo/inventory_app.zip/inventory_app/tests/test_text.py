from inventory.text import initials, normalize_name


def test_normalize():
    assert normalize_name("  Green Apple ") == "green apple"


def test_initials():
    assert initials("green apple") == "GA"
