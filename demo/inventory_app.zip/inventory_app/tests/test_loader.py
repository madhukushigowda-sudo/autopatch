from inventory.loader import load, parse_line


def test_parse_line():
    assert parse_line("apple, 10") == ("apple", 10)


def test_load_good_lines():
    assert load(["apple,10", "pear,4"]) == {"apple": 10, "pear": 4}


def test_load_skips_bad_lines():
    assert load(["apple,10", "garbage"]) == {"apple": 10}
