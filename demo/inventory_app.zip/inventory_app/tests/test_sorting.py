from inventory.sorting import cheapest_first, names


def test_cheapest_first():
    items = [("b", 5), ("a", 2), ("c", 9)]
    assert cheapest_first(items) == [("a", 2), ("b", 5), ("c", 9)]


def test_names():
    assert names([("a", 1), ("b", 2)]) == ["a", "b"]
