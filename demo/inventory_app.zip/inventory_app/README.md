# inventory_app: a deliberately buggy practice project for AutoPatch

Small Python inventory library. It contains several planted bugs of different kinds so you can try
AutoPatch's scan, Bug Intelligence and AI Repair Studio. Run the tests with `python -m pytest`.
