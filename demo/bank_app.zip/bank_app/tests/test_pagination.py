from bank.pagination import get_page, page_count


def test_first_page():
    assert get_page([1, 2, 3, 4, 5], 1, 2) == [1, 2]


def test_last_page():
    assert get_page([1, 2, 3, 4, 5], 3, 2) == [5]


def test_page_count():
    assert page_count(5, 2) == 3
