from bank.history import biggest_deposit, last_transaction


def test_last():
    assert last_transaction([1, 2, 3]) == 3


def test_last_empty():
    assert last_transaction([]) is None


def test_biggest_deposit():
    assert biggest_deposit([5, -3, 9]) == 9


def test_biggest_deposit_none():
    assert biggest_deposit([-1, -2]) is None
