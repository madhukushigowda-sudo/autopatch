from bank.interest import compound_interest, simple_interest


def test_compound_two_years():
    assert compound_interest(1000, 0.1, 2) == 1210.0


def test_simple():
    assert simple_interest(1000, 0.1, 2) == 200.0
