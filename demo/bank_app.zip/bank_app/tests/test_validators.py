from bank.validators import is_positive_number, is_valid_email


def test_email_ok():
    assert is_valid_email("a@b.com") is True


def test_email_bad():
    assert is_valid_email("nope") is False


def test_positive():
    assert is_positive_number(3) and not is_positive_number(-1)
