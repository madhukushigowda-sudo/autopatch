import pytest

from bank.ledger import check_balanced, net


def test_balanced():
    assert check_balanced([5], [5]) is True


def test_unbalanced_raises():
    with pytest.raises(AssertionError):
        check_balanced([5], [4])


def test_net():
    assert net([1, 2], [10]) == 7
