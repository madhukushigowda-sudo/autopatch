import pytest

from bank.account import Account, InsufficientFunds


def test_deposit():
    assert Account("a", 10).deposit(5) == 15


def test_withdraw_part():
    assert Account("a", 10).withdraw(4) == 6


def test_withdraw_exact_balance():
    assert Account("a", 10).withdraw(10) == 0


def test_withdraw_too_much():
    with pytest.raises(InsufficientFunds):
        Account("a", 10).withdraw(11)
