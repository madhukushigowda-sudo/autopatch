from bank.formatting import money, statement_line


def test_money():
    assert money(1234.5) == "$1,234.50"


def test_statement_line():
    assert statement_line("Asha", 250) == "Total for Asha: 250"
