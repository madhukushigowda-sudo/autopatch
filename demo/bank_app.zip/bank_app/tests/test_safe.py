from bank.safe import to_int


def test_to_int():
    assert to_int("5") == 5 and to_int("x", 9) == 9
