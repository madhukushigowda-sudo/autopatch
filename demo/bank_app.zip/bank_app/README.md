# bank_app: a second deliberately buggy practice project for AutoPatch

A tiny banking library with planted bugs (logic, runtime, import, syntax and style problems).
Run the tests with `python -m pytest`.
