"""Text output."""


def money(amount):
    return f"${amount:,.2f}"


def statement_line(name, total):
    return "Total for " + name + ": " + total
