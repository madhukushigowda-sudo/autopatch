"""A simple bank account."""


class InsufficientFunds(Exception):
    pass


class Account:
    def __init__(self, owner, balance=0):
        self.owner = owner
        self.balance = balance

    def deposit(self, amount):
        if amount <= 0:
            raise ValueError("deposit must be positive")
        self.balance += amount
        return self.balance

    def withdraw(self, amount):
        """Take money out. Withdrawing exactly the whole balance is allowed."""
        if amount >= self.balance:
            raise InsufficientFunds(f"balance {self.balance} is too low for {amount}")
        self.balance -= amount
        return self.balance
