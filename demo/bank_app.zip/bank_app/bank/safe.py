"""Correct code. AutoPatch should not report anything serious here."""
import logging

log = logging.getLogger(__name__)


def to_int(text, default=0):
    try:
        return int(text)
    except ValueError:
        return default


def cleanup(path):
    import os
    try:
        os.remove(path)
    except FileNotFoundError:
        pass
    except OSError as exc:
        log.warning("could not remove %s: %s", path, exc)
