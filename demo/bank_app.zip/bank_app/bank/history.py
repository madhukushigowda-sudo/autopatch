"""Transaction history helpers."""


def last_transaction(history):
    """Return the most recent transaction, or None for an empty history."""
    if history:
        return history[-1]


def biggest_deposit(history):
    deposits = [t for t in history if t > 0]
    return max(deposits)
