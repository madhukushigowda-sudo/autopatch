"""Input checks."""


def is_valid_email(text):
    return re.fullmatch(r"[^@\s]+@[^@\s]+\.[a-z]{2,}", text) is not None


def is_positive_number(value):
    return isinstance(value, (int, float)) and value > 0
