"""Not imported anywhere: a file with a syntax error."""


def tidy(name)
    return name.strip()
