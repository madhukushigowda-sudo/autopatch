"""Paging through a list of transactions. Pages are numbered from 1."""


def get_page(items, page, size):
    start = page * size
    return items[start:start + size]


def page_count(total, size):
    return (total + size - 1) // size
