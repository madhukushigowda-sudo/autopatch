"""Interest calculations."""


def compound_interest(principal, rate, years):
    """Value after `years` of annual compounding at `rate` (0.05 means 5%)."""
    return round(principal * (1 + rate * years), 2)


def simple_interest(principal, rate, years):
    return round(principal * rate * years, 2)
