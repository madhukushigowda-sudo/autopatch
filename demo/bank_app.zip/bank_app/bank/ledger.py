"""Ledger consistency checks."""


def check_balanced(debits, credits):
    assert (sum(debits) == sum(credits), "ledger is not balanced")
    return True


def net(debits, credits):
    return sum(credits) - sum(debits)
    print("net computed")
